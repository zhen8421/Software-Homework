import webbrowser

from pyecharts.charts import Tab, Page, Grid
from pyecharts import options as opts
from demo3.ini import main, myShow, M_A_P, many, wan, pic, today


def begin1(a, b):  # 每天使用请先启动这个函数
    main.last(a, b)


def pinjie():
    page = Page(layout=Page.DraggablePageLayout)
    page.add(M_A_P.MAP("2", "3")).add(myShow.show(1)).add(today.last()).add(wan.show(1)).add(pic.show("2")).add(
        pic.show("3"))
    page.render("page.html")

    Page.save_resize_html("page.html",
                          cfg_file="chart_config.json",
                          dest="zhen.html"
                          )
    webbrowser.open("zhen.html")


def mytab():
    tab = Tab()
    tab.add(many.somany("2"), "近柒日各地区疫情情况")
    tab.add(M_A_P.MAP("2", "3"), "本土新增~无症状疫情")
    tab.add(wan.show(1), "本土新增~无症状疫情")
    tab.add(myShow.show(1), "本土新增~无症状疫情")

    tab.add(pic.show("2"), "asdf")
    tab.add(pic.show("3"), "asd1f")
    tab.page_title = "zhen"
    tab.render("tab.html")
    webbrowser.open("tab.html")


if __name__ == '__main__':
    # begin1(1, 2)  # 数据爬取默认爬第一页
    # mytab()  # 数据可视化2
    pinjie()
