import webbrowser

import openpyxl
from pyecharts.charts import Bar
from pyecharts import options as opts
from pyecharts.charts import Bar, Grid, Line, Liquid, Page, Pie
from pyecharts.commons.utils import JsCode
from pyecharts.components import Table
from pyecharts.faker import Faker


# 读取表格
def bar_datazoom_slider(x, y, name, lol) -> Bar:
    c = (
        Bar(init_opts=opts.InitOpts(chart_id='bar'))
        .add_xaxis(x)
        .add_yaxis("确诊病例", y)
        .add_yaxis("无症状病例", lol)
        .set_series_opts(label_opts=opts.LabelOpts(position='inside'))
        .set_global_opts(
            yaxis_opts=opts.AxisOpts(name="人数"),
            xaxis_opts=opts.AxisOpts(name="日期"),
            title_opts=opts.TitleOpts(title=name),
            datazoom_opts=opts.DataZoomOpts(type_="inside"),
            legend_opts=opts.LegendOpts(is_show=True,pos_left="15%",orient='vertical')
        )
    )
    return c


def picture1(num, tl, name, data, lol):
    table = data[tl]
    xdata = []
    ydata = []
    if num == 1:
        name = "本土"
    else:
        name = "本土无症状"
    num = num + 1
    for j in range(2, table.max_row):
        xdata.append(((table.cell(j, 1)).value)[2:])
        if int((table.cell(j, num)).value) != 0:
            ydata.append(int((table.cell(j, num)).value))
        else:
            ydata.append(0)
    xdata.reverse()
    ydata.reverse()
    print(xdata)
    print(ydata)
    print(lol)
    bar = bar_datazoom_slider(xdata, ydata, name, lol)
    return bar


def picture(num, tl, name, data):
    table = data[tl]
    xdata = []
    ydata = []
    if num == 1:
        name = "本土"
    else:
        name = "本土无症状"
    num = num + 1
    for j in range(2, table.max_row):
        xdata.append((table.cell(j, 1)).value)
        if int((table.cell(j, num)).value) != 0:
            ydata.append(int((table.cell(j, num)).value))
        else:
            ydata.append(0)
    xdata.reverse()
    ydata.reverse()

    return ydata


# 画图
def show(num):
    data = openpyxl.load_workbook(r"2.xlsx")
    lol = picture(2, str(1), "", data)
    c = picture1(1, str(1), "", data, lol)

    return c

# show(1).render("ad.html")
