import openpyxl
from pyecharts import options as opts
from pyecharts.charts import Map, Timeline, Bar, Pie


def cur(where1, where2):
    ans = []
    data = openpyxl.load_workbook('2.xlsx')
    table = data[where1]
    i = 0
    li = []
    k = 1
    for j in range(2, table.max_column - 2):
        li.append(int((table.cell(k + 1, j)).value))
        i = i + 1
    ans.append(li)
    table = data[where2]
    i = 0
    li = []
    k = 1
    for j in range(2, table.max_column - 2):
        li.append(int((table.cell(k + 1, j)).value))
        i = i + 1
    ans.append(li)
    return ans


def last():
    li1 = cur("2", "3")
    name1 = [
        "河北", "山西", "辽宁", "吉林", "黑龙江", "江苏",
        "浙江", "安徽", "福建", "江西", "山东", "河南", "湖北", "湖南",
        "广东", "海南", "四川", "贵州", "云南", "陕西", "北京", "天津", "上海", "重庆",
        "甘肃", "青海", "内蒙古", "广西", "西藏", "宁夏", "新疆", "香港", "澳门", "台湾"
    ]
    name = "1"
    a = li1[0]
    b = li1[1]
    inner_data_pair = [list(z) for z in zip(name1, b)]
    outer_data_pair = [list(z) for z in zip(name1, a)]
    c = (
        Pie(init_opts=opts.InitOpts(width="600px", height="600px", chart_id="pie"))
        .add(
            series_name="无症状病例",
            data_pair=inner_data_pair,
            radius=[0, "30%"],
            label_opts=opts.LabelOpts(position="inner", is_show=False),
        )
        .add(
            series_name="确诊病例",
            radius=["40%", "55%"],
            data_pair=outer_data_pair,
            label_opts=opts.LabelOpts(
                is_show=False,
                position="outside",
                formatter="{a|{a}}{abg|}\n{hr|}\n {b|{b}: }{c}  {per|{d}%}  ",
                background_color="#eee",
                border_color="#aaa",
                border_width=1,
                border_radius=4,
                rich={
                    "a": {"color": "#999", "lineHeight": 22, "align": "center"},
                    "abg": {
                        "backgroundColor": "#e3e3e3",
                        "width": "100%",
                        "align": "right",
                        "height": 22,
                        "borderRadius": [4, 4, 0, 0],
                    },
                    "hr": {
                        "borderColor": "#aaa",
                        "width": "100%",
                        "borderWidth": 0.5,
                        "height": 0,
                    },
                    "b": {"fontSize": 16, "lineHeight": 33},
                    "per": {
                        "color": "#eee",
                        "backgroundColor": "#334455",
                        "padding": [2, 4],
                        "borderRadius": 2,
                    },
                },
            ),
        )
        .set_global_opts(legend_opts=opts.LegendOpts(pos_left="left", orient="vertical", is_show=False))
        .set_series_opts(
            tooltip_opts=opts.TooltipOpts(
                trigger="item", formatter="{a} <br/>{b}: {c} ({d}%)"
            )
        )

    )
    return c
