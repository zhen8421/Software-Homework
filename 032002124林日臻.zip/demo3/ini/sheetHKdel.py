import openpyxl

# 港澳台新增确诊病例减法
def hhhh():
    xfile = openpyxl.load_workbook('2.xlsx')
    sheet = xfile['2']
    ROW = sheet.max_row
    for j in range(36, 39):
        for i in range(2, ROW):
            a1_cell = int((sheet.cell(row=i, column=j)).value)
            a2_cell = int((sheet.cell(row=i + 1, column=j)).value)
            value = a1_cell - a2_cell
            if value < 0:
                value = 0
            sheet.cell(i, j - 3, value)
        xfile.save('2.xlsx')
