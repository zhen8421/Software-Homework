from pyecharts import options as opts
from pyecharts.charts import Map3D
from pyecharts.globals import ChartType
from pyecharts.commons.utils import JsCode
import openpyxl


def shuju(where):
    data = openpyxl.load_workbook('2.xlsx')
    table = data[where]
    ans = []
    li = {}
    row1data = []
    x = [[114.4995, 38.1006], [112.3352, 37.9413], [123.1238, 42.1216],
         [125.8154, 44.2584], [127.9688, 45.368], [118.8062, 31.9208],
         [119.5313, 29.8773], [117.29, 32.0581], [119.4543, 25.9222],
         [116.0046, 28.6633], [117.1582, 36.8701], [113.4668, 34.6234],
         [114.3896, 30.6628], [113.0823, 28.2568], [113.27, 23.13],
         [110.3893, 19.8516], [103.9526, 30.7617], [106.6992, 26.7682],
         [100.29, 25.7217], [109.1162, 34.2004], [116.46, 39.92],
         [117.4219, 39.4189], [121.4648, 31.2891], [108.384366, 30.439702],
         [103.5901, 36.3043], [101.4038, 36.8207], [110.3467, 41.4899],
         [108.479, 23.1152], [91.11, 29.97], [106.3586, 38.1775],
         [87.9236, 43.5883], [114.1733, 22.3200], [111.9586, 21.8], [121.5200, 25.0307]
         ]
    for i in range(2, table.max_column + 1):
        row1data.append((table.cell(1, i)).value)

    i = 0
    for j in range(2, table.max_column - 2):
        li[row1data[i]] = int((table.cell(2, j)).value)
        if li[row1data[i]] > 0:
            ans.append((row1data[i], [x[i][0], x[i][1], li[row1data[i]]]))
        i = i + 1
    return ans


# 画3D地图
def MAP(where1, where2):
    data = openpyxl.load_workbook('2.xlsx')
    table = data[where1]

    today = (table.cell(2, 1)).value

    example_data1 = shuju(where1)

    example_data2 = shuju(where2)
    c = (
        Map3D(init_opts=opts.InitOpts(chart_id="3dmap", width="1000px", height="600px",
                                      bg_color={"type": "pattern", "image": JsCode("img"), "repeat": "no-repeat"}))
        .add_schema(
            box_height=35,
            region_height=1,
            itemstyle_opts=opts.ItemStyleOpts(

                color='#A60B63',
                border_color='#FFFF22',
                opacity=0.8,
                border_width=0.8,

            ),
            map3d_label=opts.Map3DLabelOpts(
                is_show=False,
                formatter=JsCode("function(data){return data.name + " " + data.value[2];}"),
            ),
            emphasis_label_opts=opts.LabelOpts(
                is_show=False,
                color="#fff",
                font_size=10,
                background_color="rgba(0,23,11,0)",
            ),
            light_opts=opts.Map3DLightOpts(
                main_color="#fff",
                main_intensity=1.2,
                main_shadow_quality="high",
                is_main_shadow=False,
                main_beta=10,
                ambient_intensity=0.3,
            ),
            view_control_opts=opts.Map3DViewControlOpts(center=[-1, -10, -10], rotate_mouse_button='left',
                                                        pan_mouse_button='middle'),
        )
        .add(
            series_name="本土新增疫情",
            data_pair=example_data1,
            type_=ChartType.BAR3D,
            bar_size=1,
            shading="lambert",
            label_opts=opts.LabelOpts(
                is_show=False,
                formatter=JsCode("function(data){return data.name + ' ' + data.value[2];}"),
            ),
        )
        .add(
            series_name="本土新增无症状疫情",
            data_pair=example_data2,
            type_=ChartType.BAR3D,
            bar_size=1,
            shading="lambert",
            label_opts=opts.LabelOpts(
                is_show=False,
                formatter=JsCode("function(data){return data.name + ' ' + data.value[2];}"),
            ),
        )
        .set_global_opts(title_opts=opts.TitleOpts(title="今日({})信息".format(today)),
                         legend_opts=opts.LegendOpts(is_show=True, selected_mode='single'),
                         tooltip_opts=opts.TooltipOpts(is_show=False),
                         visualmap_opts=opts.VisualMapOpts(is_show=True,
                                                           min_=1,
                                                           max_=300, pos_top='center',
                                                           range_color=['#0050b3', '#1890FF', 'black'])
                         )
    )
    c.add_js_funcs(
        """
        var img = new Image(); 
        img.src = 'http://img.netbian.com/file/2019/1121/5e4911c7c44d251ee030cfafe3660394.jpg';
        """
    )
    return c

# MAP("2", "3").render("he.html")
