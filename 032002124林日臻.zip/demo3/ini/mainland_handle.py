import re

from demo3.ini import sheet


def create_map(str2, num):
    curlist = str2.replace("例", "").split('，')  # 方便正则处理
    dict1 = {}
    li = [
        "日期", "河北", "山西", "辽宁", "吉林", "黑龙江", "江苏",
        "浙江", "安徽", "福建", "江西", "山东", "河南", "湖北", "湖南",
        "广东", "海南", "四川", "贵州", "云南", "陕西", "北京", "天津", "上海", "重庆",
        "甘肃", "青海", "内蒙古", "广西", "西藏", "宁夏", "新疆", "香港", "澳门", "台湾", "香港1", "澳门1",
        "台湾1"
    ]
    fun = 0
    # 若出现：均在xx省或均在xx省xx市的处理
    for item in li:
        if str2.replace("例", "").find(item) != -1:
            fun = fun + 1
            if fun > 1:
                break

    if fun == 1:
        for item in li:
            if curlist[0].find(item) != -1:
                dict1[item] = num
                break

    else:
        for item in curlist:
            num = re.sub(u"([^\u0030-\u0039])", "", item)  # 数字匹配
            name = re.sub(u'([^\u4e00-\u9fa5])', '', item)  # 地名匹配
            dict1[name] = num

    return dict1


def str_handle(str1, n):
    # 方便正则处理
    str1 = str1.replace("*", "")
    str1 = str1.replace("；", "，")
    str1 = str1.replace("。", "，")
    hk = re.search("香港特别行政区(.*?)例", str1).group(1)
    am = re.search("澳门特别行政区(.*?)例", str1).group(1)
    tw = re.search("台湾地区(.*?)例", str1).group(1)
    li = [
        "日期", "河北", "山西", "辽宁", "吉林", "黑龙江", "江苏",
        "浙江", "安徽", "福建", "江西", "山东", "河南", "湖北", "湖南",
        "广东", "海南", "四川", "贵州", "云南", "陕西", "北京", "天津", "上海", "重庆",
        "甘肃", "青海", "内蒙古", "广西", "西藏", "宁夏", "新疆", "香港", "澳门", "台湾", "香港1", "澳门1",
        "台湾1"
    ]
    no_map = {}

    for item in li:
        no_map[item] = 0

    # 找新增本土确诊病例
    try:
        new_add = re.search(
            "31个省（自治区、直辖市）和新疆生产建设兵团报告新增确诊病例(.*?)例"
            "，其中境外输入病例(.*?)例（(.*?)）(.*?)，"
            "本土病例(.*?)例（(.*?)）(.*?)，",
            str1).group(5)
    except:  # 可能今日本土无新增确诊病例
        new_add = 0

    # 找本土新增无症状病例
    try:
        new_no = re.search(
            "31个省（自治区、直辖市）和新疆生产建设兵团报告新增无症状感染者(.*?)例，其中境外输入(.*?)例，本土(.*?)例（(.*?)），",
            str1).group(3)
    except:  # 可能今日本土无无症状病例
        new_no = 0

    # 正则处理
    try:
        main_land = re.search(
            "31个省（自治区、直辖市）和新疆生产建设兵团报告新增确诊病例(.*?)例"
            "，其中境外输入病例(.*?)例（(.*?)）(.*?)，"
            "(.*?)本土病(.*?)例（(.*?)）(.*?)，",  # 尽最大匹配
            str1).group(7)
        main_land_map = create_map(main_land, new_add)

        main_land_map["香港1"] = hk
        main_land_map["澳门1"] = am
        main_land_map["台湾1"] = tw
        # 处理成一个字典方便表格插入
        sheet.sheetmainland(main_land_map, n, str1[0:4] + "年" + re.search("截至(.*?)24时", str1).group(1))
    except:
        print("异常1:今日本土没有确诊病例新增")  # 抛出异常
        # 使用全0字典
        sheet.sheetmainland(no_map, n, str1[0:4] + "年" + re.search("截至(.*?)24时", str1).group(1))
    # 同上
    try:
        main_land_no = re.search(
            "31个省（自治区、直辖市）和新疆生产建设兵团报告新增无症状感染者(.*?)例，其中境外输入(.*?)例，本土(.*?)例（(.*?)），",
            str1).group(4)
        main_land_no_map = create_map(main_land_no, new_no)
        main_land_map["香港1"] = 0
        main_land_map["澳门1"] = 0
        main_land_map["台湾1"] = 0
        sheet.sheetmainlandnosingal(main_land_no_map, n, str1[0:4] + "年" + re.search("截至(.*?)24时", str1).group(1))
    except:
        print("异常2:今日本土没有无症状病例新增")
        sheet.sheetmainlandnosingal(no_map, n, str1[0:4] + "年" + re.search("截至(.*?)24时", str1).group(1))
