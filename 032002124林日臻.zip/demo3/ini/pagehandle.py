import time

import requests
from lxml import etree


# 别动
# 将html页面提取正文部分
def mypagehandle(url):
    headers = {
        "Accept": "image/avif,image/webp,*/*",
        "Accept-Encoding": "gzip, deflate",
        "Accept-Language": "zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2",
        "Connection": "keep-alive",
        "Referer": "http://www.nhc.gov.cn/",
        "Cookie": "yfx_c_g_u_id_10006654=_ck22090517092711557123132504572; yfx_f_l_v_t_10006654=f_t_1662368967158__r_t_1662514638127__v_t_1662514638127__r_c_2; yfx_mr_10006654=%3A%3Amarket_type_free_search%3A%3A%3A%3Abaidu%3A%3A%3A%3A%3A%3A%3A%3Awww.baidu.com%3A%3A%3A%3Apmf_from_free_search; yfx_mr_f_10006654=%3A%3Amarket_type_free_search%3A%3A%3A%3Abaidu%3A%3A%3A%3A%3A%3A%3A%3Awww.baidu.com%3A%3A%3A%3Apmf_from_free_search; yfx_key_10006654=; sVoELocvxVW0S=57yh5eHi6BlWwbYuOEUHFMNXf_2SF8UL5VWS1759zdOiiImwtyLuvBL1rWffIpGlLnMEMoxnpQBHoAej5Qug.gG; security_session_verify=fc465e4f1828940ec0438b63374ada0a; sVoELocvxVW0T=53SI0.DWUeQ7qqqDkmRH3_AToYARjKiHRH568jKOM4B.OPNB2axXw5kqAtweBhHBYQOYh3hRO8OaMl8SZuRBb4HDDy8wWx_H9KnDMJfOHJhLKqwvylr_gmnhMbVf7Xl1INInmRUZl8aTrrguv1MWZmyUOXCgg2aOx6_4J72Gm.uCLEdwxtjF7hWLGGpO..CyBUuKFNGN8o.f7i5cTf3DueMgKy959yMbnxH14vnDsH.wVdK4nQbz4PLAMqYCxYgwjT4eY2xujVIScYsPVxnC5uNL45UyizBvMCagu5cjSPGfoWPa5mHqCrzryZOZ96c0axMDYQTxAdJ7LeVECT_l6vDQTiBIU5G26AzdTJ07AoQza; insert_cookie=91349450",
        "Hosts": "www.nhc.gov.cn",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:104.0) Gecko/20100101 Firefox/104.0"
    }
    r1 = requests.get("http://www.nhc.gov.cn" + url, headers=headers)
    # time.sleep(3)
    time.sleep(1)
    uid = url.split('/')[3]  # 加年份

    page_text = r1.text
    tree = etree.HTML(page_text)

    text_list = tree.xpath('/html/body/div[3]/div[2]/div[3]//text()')
    text = "".join(text_list)
    if url == "/xcs/yqtb/202202/2da2f243613e4e11a92efadd652f4050.shtml":
        # 此日特殊处理
        text = "2月21日0—24时，31个省（自治区、直辖市）和新疆生产建设兵团报告新增确诊病例138例。其中境外输入病例79例（上海32例，广东22例，福建10例，北京4例，四川3例，甘肃3例，浙江2例，安徽2例，云南1例），含6例由无症状感染者转为确诊病例（广东5例，浙江1例）；本土病例59例（内蒙古20例，其中呼和浩特市18例、巴彦淖尔市1例、包头市1例；江苏12例，其中苏州市10例、无锡市2例；辽宁6例，均在葫芦岛市；四川5例，均在成都市；云南5例，其中德宏傣族景颇族自治州4例、红河哈尼族彝族自治州1例；北京4例；湖北4例，均在武汉市；广东3例，均在深圳市），含6例由无症状感染者转为确诊病例（江苏3例，四川3例）。无新增死亡病例。新增疑似病例4例，均为境外输入病例（均在上海）。当日新增治愈出院病例53例，解除医学观察的密切接触者1803人，重症病例较前一日增加2例。境外输入现有确诊病例935例（其中重症病例1例），现有疑似病例4例。累计确诊病例13551例，累计治愈出院病例12616例，无死亡病例。截至2月21日24时，据31个省（自治区、直辖市）和新疆生产建设兵团报告，现有确诊病例1809例（其中重症病例12例），累计治愈出院病例101544例，累计死亡病例4636例，累计报告确诊病例107989例，现有疑似病例4例。累计追踪到密切接触者1586886人，尚在医学观察的密切接触者39412人。31个省（自治区、直辖市）和新疆生产建设兵团报告新增无症状感染者46例，其中境外输入40例，本土6例（内蒙古2例，均在巴彦淖尔市；江苏2例，均在苏州市；四川2例，其中成都市1例、泸州市1例）；当日转为确诊病例12例（境外输入6例）；当日解除医学观察39例（境外输入38例）；尚在医学观察的无症状感染者681例（境外输入568例）。累计收到港澳台地区通报确诊病例46173例。其中，香港特别行政区26038例（出院16449例，死亡300例），澳门特别行政区79例（出院79例），台湾地区20056例（出院13742例，死亡852例）。"
    text = uid[0:4] + text
    return text;
