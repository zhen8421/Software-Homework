from demo3.ini import ghost, sheetHKdel, myShow
import openpyxl

def last(a,b):
    li = [
        "日期", "河北", "山西", "辽宁", "吉林", "黑龙江", "江苏",
        "浙江", "安徽", "福建", "江西", "山东", "河南", "湖北", "湖南",
        "广东", "海南", "四川", "贵州", "云南", "陕西", "北京", "天津", "上海", "重庆",
        "甘肃", "青海", "内蒙古", "广西", "西藏", "宁夏", "新疆", "香港", "澳门", "台湾", "香港1", "澳门1",
        "台湾1"
    ]
    op = [
        "日期", "本土新增", "本土新增无症状感染者", "香港", "澳门", "台湾"
    ]

    num = 1
    # 建表
    wb = openpyxl.Workbook()
    wb.remove(wb["Sheet"])
    table1 = wb.create_sheet("1")
    table1.append(op)
    table2 = wb.create_sheet("2")
    table2.append(li)
    table3 = wb.create_sheet("3")
    table3.append(li)
    wb.save("2.xlsx")
    # 开始爬取
    ghost.myghost(a, b, num)  # 1->35页内都可以完整爬取,截至2020.5.21,excel中信息有效,之后的内容部分可与正则匹配,请尽量在范围内查询
    sheetHKdel.hhhh()


