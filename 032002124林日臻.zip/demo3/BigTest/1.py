import unittest

from demo3.hot import hotsearch


class MyTestCase(unittest.TestCase):
    def test_something(self):
        self.assertEqual(hotsearch.findhot().render("1.html"), str)


if __name__ == '__main__':
    unittest.main()
