import openpyxl
from pyecharts import options as opts
from pyecharts.charts import Map, Timeline

# 画图
def mylis(where):
    data = openpyxl.load_workbook('2.xlsx')
    table = data[where]

    ans = []
    day = []
    i = 0
    for k in range(1, 8):
        li = []
        day.append((table.cell(k + 1, 1)).value)
        for j in range(2, table.max_column - 2):
            li.append(int((table.cell(k + 1, j)).value))
            i = i + 1
        ans.append(li)
    ans.reverse()
    return ans


def somany(where):
    data = openpyxl.load_workbook('2.xlsx')
    table = data[where]

    name = [
        "河北", "山西", "辽宁", "吉林", "黑龙江", "江苏",
        "浙江", "安徽", "福建", "江西", "山东", "河南", "湖北", "湖南",
        "广东", "海南", "四川", "贵州", "云南", "陕西", "北京", "天津", "上海", "重庆",
        "甘肃", "青海", "内蒙古", "广西", "西藏", "宁夏", "新疆", "香港", "澳门", "台湾"
    ]
    day = []
    for k in range(1, 8):
        day.append((table.cell(k + 1, 1)).value)
    day.reverse()
    ans1 = mylis("2")
    ans2 = mylis("3")
    tl = Timeline()
    for i in range(1, 8):
        map0 = (
            Map(init_opts=opts.InitOpts(theme='purple-passion'))
            .add("新增确诊病例", [list(z) for z in zip(name, ans1[i - 1])], "china")
            .add("新增无症状病例", [list(z) for z in zip(name, ans2[i - 1])], "china")
            .set_global_opts(
                title_opts=opts.TitleOpts(title="{0}数据".format(day[i - 1])),
                legend_opts=opts.LegendOpts(is_show=True, selected_mode='single'),
                visualmap_opts=opts.VisualMapOpts(max_=200),
            )
        )
        tl.add(map0, "{0}".format(day[i - 1]))
    return tl
