import time
import requests
from bs4 import BeautifulSoup
from demo3.ini import mainland_handle, pagehandle, text_handle


def te(url1, i):
    s1 = pagehandle.mypagehandle(url1)  # 拿html文本信息
    text_handle.str_handle(str(s1), i)  # 本土新增与无症状感染者处理
    # time.sleep(1)
    mainland_handle.str_handle(str(s1), i)  # 省份处理
    # time.sleep(1)


def myghost(start, end, num):
    headers = {
        "Accept": "image/avif,image/webp,*/*",
        "Accept-Encoding": "gzip, deflate",
        "Accept-Language": "zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2",
        "Connection": "keep-alive",
        "Referer": "http://www.nhc.gov.cn/",
        "Cookie": "yfx_c_g_u_id_10006654=_ck22090517092711557123132504572; yfx_f_l_v_t_10006654=f_t_1662368967158__r_t_1662514638127__v_t_1662514638127__r_c_2; yfx_mr_10006654=%3A%3Amarket_type_free_search%3A%3A%3A%3Abaidu%3A%3A%3A%3A%3A%3A%3A%3Awww.baidu.com%3A%3A%3A%3Apmf_from_free_search; yfx_mr_f_10006654=%3A%3Amarket_type_free_search%3A%3A%3A%3Abaidu%3A%3A%3A%3A%3A%3A%3A%3Awww.baidu.com%3A%3A%3A%3Apmf_from_free_search; yfx_key_10006654=; sVoELocvxVW0S=57yh5eHi6BlWwbYuOEUHFMNXf_2SF8UL5VWS1759zdOiiImwtyLuvBL1rWffIpGlLnMEMoxnpQBHoAej5Qug.gG; security_session_verify=fc465e4f1828940ec0438b63374ada0a; sVoELocvxVW0T=53SI0.DWUeQ7qqqDkmRH3_AToYARjKiHRH568jKOM4B.OPNB2axXw5kqAtweBhHBYQOYh3hRO8OaMl8SZuRBb4HDDy8wWx_H9KnDMJfOHJhLKqwvylr_gmnhMbVf7Xl1INInmRUZl8aTrrguv1MWZmyUOXCgg2aOx6_4J72Gm.uCLEdwxtjF7hWLGGpO..CyBUuKFNGN8o.f7i5cTf3DueMgKy959yMbnxH14vnDsH.wVdK4nQbz4PLAMqYCxYgwjT4eY2xujVIScYsPVxnC5uNL45UyizBvMCagu5cjSPGfoWPa5mHqCrzryZOZ96c0axMDYQTxAdJ7LeVECT_l6vDQTiBIU5G26AzdTJ07AoQza; insert_cookie=91349450",
        "Hosts": "www.nhc.gov.cn",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:104.0) Gecko/20100101 Firefox/104.0"
    }
    for i in range(start, end):  # 拿url
        if i == 1:
            r1 = requests.get("http://www.nhc.gov.cn/xcs/yqtb/list_gzbd.shtml", headers=headers)
        else:
            r1 = requests.get("http://www.nhc.gov.cn/xcs/yqtb/list_gzbd_" + str(i) + ".shtml", headers=headers)
        time.sleep(1)
        bosj = BeautifulSoup(r1.text, 'html.parser')
        for item in bosj.select('div[class="list"] li a'):
            detail_url = item.get('href')
            if detail_url == '/xcs/yqtb/202111/53b53f738b8040ed85541b1ac96a58c6.shtml' or detail_url == '/xcs/yqtb/202108/d8b24b4d51624a6aa95ba73297095ab7.shtml':  # 用不了的
                print("《国务院联防联控机制新闻发布会文字实录》不处于解析范围内")
            else:
                try:  # 异常处理，不能处理的url就抛出
                    te(detail_url, num)
                    num = num + 1
                except:
                    print(detail_url)
