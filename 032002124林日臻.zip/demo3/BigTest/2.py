import cProfile
import demo3.start

cProfile.run('../start.py')
