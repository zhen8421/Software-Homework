import re

from demo3.ini import sheet


# 别动

# 处理本土新增确诊与无症状，港澳台
def str_handle(str1, i):
    print("{0}年{1}信息开始导入".format(str1[0:4], re.search("截至(.*?)24时", str1).group(1)))
    new_add = re.search("31个省（自治区、直辖市）和新疆生产建设兵团报告新增确诊病例(.*?)例", str1).group(1)
    new_no = re.search("省（自治区、直辖市）和新疆生产建设兵团报告新增无症状感染者(.*?)例", str1).group(1)
    hk = re.search("香港特别行政区(.*?)例", str1).group(1)
    am = re.search("澳门特别行政区(.*?)例", str1).group(1)
    tw = re.search("台湾地区(.*?)例", str1).group(1)
    sheet.sheetdeploy(i, str1[0:4] + "年" + re.search("截至(.*?)24时", str1).group(1), new_add, new_no, hk, am, tw)
