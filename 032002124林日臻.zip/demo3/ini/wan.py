import openpyxl
import pyecharts.options as opts
from pyecharts.charts import Line


def picture1(num, tl, name, data, lol):
    table = data[tl]
    xdata = []
    ydata = []
    if num == 1:
        name = "本土"
    else:
        name = "本土无症状"
    num = num + 1
    for j in range(2, table.max_row):
        xdata.append(((table.cell(j, 1)).value)[2:])
        if int((table.cell(j, num)).value) != 0:
            ydata.append(int((table.cell(j, num)).value))
        else:
            ydata.append(0)
    xdata.reverse()
    ydata.reverse()
    bar = line(xdata, ydata, name, lol)
    return bar


def picture(num, tl, name, data):
    table = data[tl]
    xdata = []
    ydata = []
    if num == 1:
        name = "本土"
    else:
        name = "本土无症状"
    num = num + 1
    for j in range(2, table.max_row):
        xdata.append((table.cell(j, 1)).value)
        if int((table.cell(j, num)).value) != 0:
            ydata.append(int((table.cell(j, num)).value))
        else:
            ydata.append(0)
    xdata.reverse()
    ydata.reverse()
    return ydata


# 画图
def show(num):
    data = openpyxl.load_workbook(r"2.xlsx")
    lol = picture(2, str(1), "", data)
    c = picture1(1, str(1), "", data, lol)

    return c


def line(x1, y1, name, y2):
    c = (
        Line(init_opts=opts.InitOpts(chart_id="line"))
        .add_xaxis(xaxis_data=x1)
        .add_yaxis(
            series_name="确诊病例",
            y_axis=y1,
            symbol="triangle",
            symbol_size=5,
            linestyle_opts=opts.LineStyleOpts(color="black", width=1, type_="dashed"),
            label_opts=opts.LabelOpts(is_show=True),
            itemstyle_opts=opts.ItemStyleOpts(
                border_width=1, border_color="black", color="red"
            ),
        )
        .add_yaxis(
            series_name="无症状感染者",
            y_axis=y2,
            symbol="circle",
            symbol_size=5,
            linestyle_opts=opts.LineStyleOpts(color="green", width=1, type_="dashed"),
            label_opts=opts.LabelOpts(is_show=True),
            itemstyle_opts=opts.ItemStyleOpts(
                border_width=1, border_color="grey", color="blue"
            ),
        )
        .set_global_opts(
            datazoom_opts=opts.DataZoomOpts(type_="inside"),
            xaxis_opts=opts.AxisOpts(type_="category"),
            yaxis_opts=opts.AxisOpts(
                type_="value",
                axistick_opts=opts.AxisTickOpts(is_show=True),
                splitline_opts=opts.SplitLineOpts(is_show=True),
            ),
            tooltip_opts=opts.TooltipOpts(is_show=True),
        )

    )

    return c

