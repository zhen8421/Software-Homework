import openpyxl
from pyecharts.charts import WordCloud
from pyecharts import options as opts
from pyecharts.charts import Bar

from pyecharts.globals import SymbolType


# 读取表格
def bar_datazoom_slider(x, num) -> Bar:
    ans1 = []
    for i in range(0, len(x)):
        ans1.append((x[i][0], x[i][1]))
    c = (
        WordCloud(init_opts=opts.InitOpts(chart_id="dd" + str(num)))
        .add("词云", ans1, word_size_range=[20, 100], shape=SymbolType.DIAMOND)
        .set_global_opts(title_opts=opts.TitleOpts(title=""))
    )
    return c


def shuju(where):
    data = openpyxl.load_workbook('2.xlsx')
    table = data[where]
    ans = []
    li = {}
    row1data = []
    x = [[114.4995, 38.1006], [112.3352, 37.9413], [123.1238, 42.1216],
         [125.8154, 44.2584], [127.9688, 45.368], [118.8062, 31.9208],
         [119.5313, 29.8773], [117.29, 32.0581], [119.4543, 25.9222],
         [116.0046, 28.6633], [117.1582, 36.8701], [113.4668, 34.6234],
         [114.3896, 30.6628], [113.0823, 28.2568], [113.27, 23.13],
         [110.3893, 19.8516], [103.9526, 30.7617], [106.6992, 26.7682],
         [100.29, 25.7217], [109.1162, 34.2004], [116.46, 39.92],
         [117.4219, 39.4189], [121.4648, 31.2891], [108.384366, 30.439702],
         [103.5901, 36.3043], [101.4038, 36.8207], [110.3467, 41.4899],
         [108.479, 23.1152], [91.11, 29.97], [106.3586, 38.1775],
         [87.9236, 43.5883], [114.1733, 22.3200], [111.9586, 21.8], [121.5200, 25.0307]
         ]
    for i in range(2, table.max_column + 1):
        row1data.append((table.cell(1, i)).value)

    i = 0
    for j in range(2, table.max_column - 2):
        li[row1data[i]] = int((table.cell(2, j)).value)
        ans.append((row1data[i], li[row1data[i]]))
        i = i + 1
    return ans


def show(num):
    ans1 = shuju(num)
    c = bar_datazoom_slider(ans1, num)
    return c

# show(1).render("ad.html")
